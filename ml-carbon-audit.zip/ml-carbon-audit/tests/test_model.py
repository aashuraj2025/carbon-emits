import pytest
pytest.importorskip("sklearn")
from carbon_audit import Workload, phases
from carbon_audit.model import synthetic, train, CarbonModel


@pytest.fixture(scope="module")
def model(tmp_path_factory):
    path = str(tmp_path_factory.mktemp("m") / "m.joblib")
    rows, y = synthetic(1500)
    metrics = train(rows, y, path)
    return CarbonModel(path), metrics


def test_accuracy(model):
    assert model[1]["mape"] < 0.25


def test_prediction_close_to_physics(model):
    w = Workload()
    p = model[0].predict(w)
    assert abs(p["kwh"] - sum(phases(w).values())) / sum(phases(w).values()) < 0.35


def test_alert_levels(model):
    m, w = model[0], Workload()
    assert m.alert(w, 1000)["level"] == "ok"
    assert m.alert(w, 0.001)["level"] == "critical"
