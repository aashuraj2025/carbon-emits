"""Measure real energy with CodeCarbon instead of estimating."""
from contextlib import contextmanager


@contextmanager
def tracked(project: str = "ml-run", every_s: int = 15):
    from codecarbon import EmissionsTracker  # pip install "carbon-audit[track]"
    tracker = EmissionsTracker(project_name=project, measure_power_secs=every_s)
    result = {"kg_co2e": None}
    tracker.start()
    try:
        yield result
    finally:
        result["kg_co2e"] = tracker.stop()
